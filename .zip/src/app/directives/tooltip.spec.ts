import { Tooltip } from './tooltip';

describe('Tooltip', () => {
  it('should create an instance', () => {
    const directive = new Tooltip();
    expect(directive).toBeTruthy();
  });
});
